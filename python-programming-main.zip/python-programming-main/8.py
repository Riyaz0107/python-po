elements = [47, 34, 21, 89, 12]
element_to_insert = 100
position = 4
elements.insert(position, element_to_insert)
print("Modified list:", elements)
