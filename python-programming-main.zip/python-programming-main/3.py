N=int(input("Enter the limit:"))
count=0
for i in range(1,N+1):
    count+=i
print("Sum of N natural numbers",count)
